require('./bootstrap');

alert('Hello JS');
