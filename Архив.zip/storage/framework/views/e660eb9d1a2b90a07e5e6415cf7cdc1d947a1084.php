<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <?php echo $__env->make('styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Фото редактор</title>
    <?php echo $__env->yieldPushContent('header'); ?>

</head>
<body>

<?php echo $__env->yieldContent('content'); ?>

</body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/pictures/resources/views/app.blade.php ENDPATH**/ ?>