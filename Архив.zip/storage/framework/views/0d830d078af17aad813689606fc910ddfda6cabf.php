<?php $__env->startSection('content'); ?>
    <!-- jsSourses скрипты -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script src="jsSourses/vendor/jquery.ui.widget.js"></script>
    <script src="jsSourses/jquery.iframe-transport.js"></script>
    <script src="jsSourses/jquery.fileupload.js"></script>
    <script>
        $('#fileupload').fileupload({
            /* ... */
            progressall: function (e, data) {
                var progress = parseInt(data.loaded / data.total * 100, 10);
                $('#progress .bar').css(
                    'width',
                    progress + '%'
                );
            }
        });
    </script>

    <div class="flex-center position-ref full-height">
        <?php if(Route::has('login')): ?>
            <div class="top-right links">
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(url('/home')); ?>">Home</a>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>">Login</a>

                    <?php if(Route::has('register')): ?>
                        <a href="<?php echo e(route('register')); ?>">Register</a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="content">
            <div class="title m-b-md">
                <p>Добро пожаловать на сайт для обработки фото</p>
            </div>
            <form action="<?php echo e(url('images')); ?>" method="POST" enctype="multipart/form-data" name="photo">
                <p><strong>Укажите картинку</strong></p>
                <div id="progress">
                    <div class="bar" style="width: 0%;"></div>
                </div>
                <p><input type="file" name="img" id="fileupload" accept="image/*" max="31457280"/>
                    <input type="submit" value="Отправить"></p>
                <?php echo csrf_field(); ?>
            </form>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/pictures/resources/views/welcome.blade.php ENDPATH**/ ?>